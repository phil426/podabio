-- Check Theme System Migration Status
-- Run this in phpMyAdmin to verify current database structure

-- 1. Check themes table structure
DESCRIBE themes;

-- 2. Check pages table structure  
DESCRIBE pages;

-- 3. Check if new columns exist in themes
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'themes'
  AND COLUMN_NAME IN ('user_id', 'page_background', 'widget_styles', 'spatial_effect')
ORDER BY ORDINAL_POSITION;

-- 4. Check if new columns exist in pages
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'pages'
  AND COLUMN_NAME IN ('page_background', 'widget_styles', 'spatial_effect')
ORDER BY ORDINAL_POSITION;

-- 5. Check if index exists on themes.user_id
SHOW INDEX FROM themes WHERE Key_name = 'idx_user_id';

-- 6. Summary - Count existing columns
SELECT 
    'themes' AS table_name,
    COUNT(*) AS new_columns_count
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'themes'
  AND COLUMN_NAME IN ('user_id', 'page_background', 'widget_styles', 'spatial_effect')
UNION ALL
SELECT 
    'pages' AS table_name,
    COUNT(*) AS new_columns_count
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'pages'
  AND COLUMN_NAME IN ('page_background', 'widget_styles', 'spatial_effect');

