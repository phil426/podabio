-- Podn.Bio Seed Data
-- Initial data to populate database

-- Insert default themes
INSERT INTO themes (name, colors, fonts, preview_image, is_active) VALUES
('Minimal', 
 '{"primary": "#000000", "secondary": "#ffffff", "accent": "#0066ff"}',
 '{"heading": "Inter", "body": "Inter"}',
 NULL,
 1),
('Bold',
 '{"primary": "#ff0066", "secondary": "#ffffff", "accent": "#00ff66"}',
 '{"heading": "Poppins", "body": "Open Sans"}',
 NULL,
 1),
('Classic',
 '{"primary": "#333333", "secondary": "#f5f5f5", "accent": "#007bff"}',
 '{"heading": "Roboto", "body": "Roboto"}',
 NULL,
 1),
('Dark',
 '{"primary": "#ffffff", "secondary": "#1a1a1a", "accent": "#00d4ff"}',
 '{"heading": "Montserrat", "body": "Source Sans Pro"}',
 NULL,
 1);

-- Insert default support categories
INSERT INTO support_categories (name, slug, description, display_order) VALUES
('Getting Started', 'getting-started', 'Learn the basics of using Podn.Bio', 1),
('Account Management', 'account-management', 'Manage your account settings and profile', 2),
('Customization', 'customization', 'Customize your page appearance and layout', 3),
('RSS Integration', 'rss-integration', 'Connect and manage your podcast RSS feed', 4),
('Links & Content', 'links-content', 'Add and manage links and content', 5),
('Email Integration', 'email-integration', 'Connect email services and manage subscriptions', 6),
('Analytics', 'analytics', 'Understand your page analytics and reports', 7),
('Subscriptions', 'subscriptions', 'Manage your subscription and billing', 8),
('Custom Domains', 'custom-domains', 'Connect your custom domain', 9),
('Troubleshooting', 'troubleshooting', 'Common issues and solutions', 10);

-- Insert default blog categories
INSERT INTO blog_categories (name, slug, description, display_order) VALUES
('Product Updates', 'product-updates', 'Latest features and improvements', 1),
('Podcasting Tips', 'podcasting-tips', 'Tips for growing your podcast', 2),
('Marketing', 'marketing', 'Marketing strategies for content creators', 3),
('Case Studies', 'case-studies', 'Success stories from our users', 4),
('Announcements', 'announcements', 'Company news and announcements', 5);

-- Note: Test accounts are in a separate file: test_accounts.sql
-- Import test_accounts.sql after seed_data.sql for testing accounts

