-- Migration: Rename podcast_directories table to social_icons
-- Run this migration to update the database schema

-- Rename the table
RENAME TABLE podcast_directories TO social_icons;

-- Update the comment on the table
ALTER TABLE social_icons COMMENT = 'Social icons and platform links for pages';

