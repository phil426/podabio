-- Theme System Migration SQL
-- Adds user themes, page backgrounds, widget styles, and spatial effects
-- Version: 1.1.0

-- Update themes table
ALTER TABLE themes ADD COLUMN user_id INT UNSIGNED NULL AFTER preview_image;
ALTER TABLE themes ADD COLUMN page_background VARCHAR(500) NULL AFTER fonts;
ALTER TABLE themes ADD COLUMN widget_styles JSON NULL AFTER page_background;
ALTER TABLE themes ADD COLUMN spatial_effect VARCHAR(50) NULL DEFAULT 'none' AFTER widget_styles;
CREATE INDEX idx_user_id ON themes(user_id);
ALTER TABLE themes ADD CONSTRAINT fk_themes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
UPDATE themes SET user_id = NULL WHERE user_id IS NULL;

-- Update pages table
ALTER TABLE pages ADD COLUMN page_background VARCHAR(500) NULL AFTER fonts;
ALTER TABLE pages ADD COLUMN widget_styles JSON NULL AFTER page_background;
ALTER TABLE pages ADD COLUMN spatial_effect VARCHAR(50) NULL DEFAULT 'none' AFTER widget_styles;

