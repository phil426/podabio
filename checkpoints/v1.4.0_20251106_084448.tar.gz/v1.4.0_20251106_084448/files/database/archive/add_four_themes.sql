-- Add Four New Themes to Database
-- Ocean, Sunset, Forest, and Violet themes

INSERT INTO themes (name, colors, fonts, preview_image, is_active) VALUES
('Ocean', 
 '{"primary": "#0a2540", "secondary": "#f0f7ff", "accent": "#00a8e8"}',
 '{"heading": "Montserrat", "body": "Open Sans"}',
 NULL,
 1),
('Sunset',
 '{"primary": "#2d1b3d", "secondary": "#fff5e6", "accent": "#ff6b35"}',
 '{"heading": "Playfair Display", "body": "Lato"}',
 NULL,
 1),
('Forest',
 '{"primary": "#1a3a2e", "secondary": "#f5faf7", "accent": "#4ade80"}',
 '{"heading": "Merriweather", "body": "Source Sans Pro"}',
 NULL,
 1),
('Violet',
 '{"primary": "#4c1d95", "secondary": "#faf5ff", "accent": "#a855f7"}',
 '{"heading": "Poppins", "body": "Nunito"}',
 NULL,
 1);

