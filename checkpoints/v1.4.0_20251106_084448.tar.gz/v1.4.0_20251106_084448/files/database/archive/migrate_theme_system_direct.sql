-- Theme System Migration - Direct SQL
-- Run this in phpMyAdmin or via MySQL command line
-- Version: 1.1.0

-- Update themes table
ALTER TABLE themes ADD COLUMN user_id INT UNSIGNED NULL AFTER preview_image;
ALTER TABLE themes ADD COLUMN page_background VARCHAR(500) NULL AFTER fonts;
ALTER TABLE themes ADD COLUMN widget_styles JSON NULL AFTER page_background;
ALTER TABLE themes ADD COLUMN spatial_effect VARCHAR(50) NULL DEFAULT 'none' AFTER widget_styles;

-- Add index for user_id (skip if already exists)
-- CREATE INDEX idx_user_id ON themes(user_id);

-- Add foreign key constraint (skip if already exists or users table doesn't exist)
-- ALTER TABLE themes ADD CONSTRAINT fk_themes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- Ensure all existing themes have user_id = NULL (system themes)
UPDATE themes SET user_id = NULL WHERE user_id IS NULL;

-- Update pages table
ALTER TABLE pages ADD COLUMN page_background VARCHAR(500) NULL AFTER fonts;
ALTER TABLE pages ADD COLUMN widget_styles JSON NULL AFTER page_background;
ALTER TABLE pages ADD COLUMN spatial_effect VARCHAR(50) NULL DEFAULT 'none' AFTER widget_styles;

-- Success message
SELECT 'Theme system migration completed successfully!' AS message;

