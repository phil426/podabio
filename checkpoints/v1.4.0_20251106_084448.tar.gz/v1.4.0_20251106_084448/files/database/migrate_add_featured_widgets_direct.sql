-- Migration: Add Featured Widget Fields
-- Adds is_featured and featured_effect columns to widgets table
-- 
-- IMPORTANT: Backup your 'widgets' table BEFORE running this migration!
-- You can backup using: mysqldump -u [username] -p[password] [database_name] widgets > widgets_backup_YYYYMMDD_HHMMSS.sql
-- Or use the provided PHP script: php database_backup_widgets.php

-- Check if columns already exist (manual check required)
-- Run: SHOW COLUMNS FROM widgets LIKE 'is_featured';
-- If no results, proceed with migration

-- Add is_featured column
ALTER TABLE widgets ADD COLUMN is_featured TINYINT(1) DEFAULT 0 AFTER is_active;

-- Add featured_effect column
ALTER TABLE widgets ADD COLUMN featured_effect VARCHAR(50) DEFAULT NULL AFTER is_featured;

-- Add index for featured widgets (only if not exists)
CREATE INDEX IF NOT EXISTS idx_is_featured ON widgets(is_featured);

-- Migration complete!
-- Verify with: DESCRIBE widgets;
-- You should see:
--   is_featured (tinyint(1), default 0)
--   featured_effect (varchar(50), nullable)

