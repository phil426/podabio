-- Test Accounts and Sample Data for Podn.Bio
-- These accounts are for testing features and functionality

-- Test Users
INSERT INTO users (email, password_hash, email_verified, created_at) VALUES
-- Popular Podcast Test Accounts
('test.serial@podn.bio', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdYl1xKN9dE.9PG', 1, NOW()), -- Password: TestSerial123!
('test.radiolab@podn.bio', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdYl1xKN9dE.9PG', 1, NOW()), -- Password: TestRadioLab123!
('test.freakonomics@podn.bio', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdYl1xKN9dE.9PG', 1, NOW()), -- Password: TestFreakonomics123!
('test.tedtalks@podn.bio', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdYl1xKN9dE.9PG', 1, NOW()), -- Password: TestTED123!
('test.thejoe@podn.bio', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdYl1xKN9dE.9PG', 1, NOW()), -- Password: TestJoeRogan123!
-- Cursor Admin Test Account
('cursor@podn.bio', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdYl1xKN9dE.9PG', 1, NOW()); -- Password: CursorAdmin123!

-- Note: All test passwords are hashed with bcrypt (cost 12)
-- Common password for all test accounts: "TestPodcast123!" (except Cursor: "CursorAdmin123!")

-- Create Pages for Test Accounts
INSERT INTO pages (user_id, username, podcast_name, podcast_description, cover_image_url, theme_id, layout_option, rss_feed_url, created_at) VALUES
-- Serial Podcast
((SELECT id FROM users WHERE email = 'test.serial@podn.bio'), 'serial', 
 'Serial', 
 'A podcast from the creators of This American Life. One story, told week by week.',
 'https://via.placeholder.com/1400x1400/FF6B6B/FFFFFF?text=Serial',
 1, 'layout1', 'https://feeds.simplecast.com/qm_9xx0g', NOW()),

-- Radiolab
((SELECT id FROM users WHERE email = 'test.radiolab@podn.bio'), 'radiolab', 
 'Radiolab', 
 'Investigating a strange world. Radiolab is a show about curiosity.',
 'https://via.placeholder.com/1400x1400/4ECDC4/FFFFFF?text=Radiolab',
 2, 'layout1', 'https://feeds.wnyc.org/radiolab', NOW()),

-- Freakonomics Radio
((SELECT id FROM users WHERE email = 'test.freakonomics@podn.bio'), 'freakonomics', 
 'Freakonomics Radio', 
 'Discover the hidden side of everything with Stephen J. Dubner.',
 'https://via.placeholder.com/1400x1400/FFE66D/000000?text=Freakonomics',
 3, 'layout2', 'https://feeds.freakonomics.com/freakonomicsradio', NOW()),

-- TED Talks Daily
((SELECT id FROM users WHERE email = 'test.tedtalks@podn.bio'), 'tedtalks', 
 'TED Talks Daily', 
 'Ideas worth spreading. Talks and performances from the TED conference.',
 'https://via.placeholder.com/1400x1400/E63946/FFFFFF?text=TED+Talks',
 1, 'layout1', 'https://feeds.npr.org/510289/podcast.xml', NOW()),

-- The Joe Rogan Experience
((SELECT id FROM users WHERE email = 'test.thejoe@podn.bio'), 'joerogan', 
 'The Joe Rogan Experience', 
 'Long form conversations with the best minds in the world.',
 'https://via.placeholder.com/1400x1400/1A1A1A/FFFFFF?text=JRE',
 4, 'layout2', 'https://feeds.megaphone.fm/JREINTERVIEWS', NOW()),

-- Cursor Test Account
((SELECT id FROM users WHERE email = 'cursor@podn.bio'), 'cursor', 
 'Cursor Test Podcast', 
 'Test account for Cursor to test admin functionality and features.',
 'https://via.placeholder.com/1400x1400/6366F1/FFFFFF?text=Cursor+Test',
 1, 'layout1', NULL, NOW());

-- Create Default Subscriptions for Test Users
INSERT INTO subscriptions (user_id, plan_type, status, started_at) VALUES
((SELECT id FROM users WHERE email = 'test.serial@podn.bio'), 'premium', 'active', NOW()),
((SELECT id FROM users WHERE email = 'test.radiolab@podn.bio'), 'free', 'active', NOW()),
((SELECT id FROM users WHERE email = 'test.freakonomics@podn.bio'), 'pro', 'active', NOW()),
((SELECT id FROM users WHERE email = 'test.tedtalks@podn.bio'), 'free', 'active', NOW()),
((SELECT id FROM users WHERE email = 'test.thejoe@podn.bio'), 'premium', 'active', NOW()),
((SELECT id FROM users WHERE email = 'cursor@podn.bio'), 'pro', 'active', NOW());

-- Sample Podcast Directory Links for Serial
INSERT INTO links (page_id, type, title, url, icon, display_order, created_at) VALUES
((SELECT id FROM pages WHERE username = 'serial'), 'podcast_directory', 'Apple Podcasts', 'https://podcasts.apple.com/us/podcast/serial/id917918570', 'apple_podcasts', 1, NOW()),
((SELECT id FROM pages WHERE username = 'serial'), 'podcast_directory', 'Spotify', 'https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk', 'spotify', 2, NOW()),
((SELECT id FROM pages WHERE username = 'serial'), 'podcast_directory', 'Amazon Music', 'https://music.amazon.com/podcasts/Serial', 'amazon_music', 3, NOW());

-- Sample Podcast Directory Links for Radiolab
INSERT INTO links (page_id, type, title, url, icon, display_order, created_at) VALUES
((SELECT id FROM pages WHERE username = 'radiolab'), 'podcast_directory', 'Apple Podcasts', 'https://podcasts.apple.com/us/podcast/radiolab/id152249110', 'apple_podcasts', 1, NOW()),
((SELECT id FROM pages WHERE username = 'radiolab'), 'podcast_directory', 'Spotify', 'https://open.spotify.com/show/4kCr0lUL1bQh3pSd7GdZ2f', 'spotify', 2, NOW());

-- Sample Custom Links for Freakonomics
INSERT INTO links (page_id, type, title, url, display_order, created_at) VALUES
((SELECT id FROM pages WHERE username = 'freakonomics'), 'custom', 'Official Website', 'https://freakonomics.com', 1, NOW()),
((SELECT id FROM pages WHERE username = 'freakonomics'), 'custom', 'Book Series', 'https://freakonomics.com/books/', 2, NOW()),
((SELECT id FROM pages WHERE username = 'freakonomics'), 'social', 'Twitter', 'https://twitter.com/freakonomics', 3, NOW()),
((SELECT id FROM pages WHERE username = 'freakonomics'), 'affiliate', 'Buy the Book', 'https://amazon.com/dp/B00X8Z2ZQ2?tag=freakonomics-20', 4, NOW());

-- Sample Social Media Links for TED Talks
INSERT INTO links (page_id, type, title, url, icon, display_order, created_at) VALUES
((SELECT id FROM pages WHERE username = 'tedtalks'), 'social', 'Twitter', 'https://twitter.com/TEDTalks', 'twitter', 1, NOW()),
((SELECT id FROM pages WHERE username = 'tedtalks'), 'social', 'Facebook', 'https://facebook.com/TED', 'facebook', 2, NOW()),
((SELECT id FROM pages WHERE username = 'tedtalks'), 'social', 'Instagram', 'https://instagram.com/ted', 'instagram', 3, NOW()),
((SELECT id FROM pages WHERE username = 'tedtalks'), 'social', 'YouTube', 'https://youtube.com/ted', 'youtube', 4, NOW());

-- Sample Links for Joe Rogan
INSERT INTO links (page_id, type, title, url, display_order, created_at) VALUES
((SELECT id FROM pages WHERE username = 'joerogan'), 'podcast_directory', 'Spotify', 'https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk', 1, NOW()),
((SELECT id FROM pages WHERE username = 'joerogan'), 'sponsor', 'Onnit Supplements', 'https://onnit.com/rogan', 2, NOW()),
((SELECT id FROM pages WHERE username = 'joerogan'), 'affiliate', 'Show Merch', 'https://shop.joerogan.com', 3, NOW()),
((SELECT id FROM pages WHERE username = 'joerogan'), 'social', 'Instagram', 'https://instagram.com/joerogan', 4, NOW());

-- Sample Links for Cursor Test Account (Admin Testing)
INSERT INTO links (page_id, type, title, url, display_order, created_at) VALUES
((SELECT id FROM pages WHERE username = 'cursor'), 'custom', 'Test Custom Link', 'https://example.com/test', 1, NOW()),
((SELECT id FROM pages WHERE username = 'cursor'), 'affiliate', 'Test Affiliate Link', 'https://amazon.com/test?tag=test-20', 2, NOW()),
((SELECT id FROM pages WHERE username = 'cursor'), 'sponsor', 'Test Sponsor Link', 'https://example.com/sponsor', 3, NOW()),
((SELECT id FROM pages WHERE username = 'cursor'), 'email_subscribe', 'Subscribe to Email List', '#', 4, NOW()),
((SELECT id FROM pages WHERE username = 'cursor'), 'social', 'Test Twitter', 'https://twitter.com/test', 5, NOW());

-- Sample Episodes for Serial (to test episode drawer)
INSERT INTO episodes (page_id, title, description, pub_date, audio_url, duration, episode_number, guid, created_at) VALUES
((SELECT id FROM pages WHERE username = 'serial'), 
 'Episode 1: The Alibi', 
 'In 1999, Hae Min Lee, a popular high-school senior, disappeared after school one day. Six weeks later, detectives arrested her classmate and ex-boyfriend, Adnan Syed, for her murder.', 
 '2014-10-03 12:00:00', 
 'https://example.com/episodes/serial-ep1.mp3', 
 3600, 
 1, 
 'serial-ep1', 
 NOW()),

((SELECT id FROM pages WHERE username = 'serial'), 
 'Episode 2: The Breakup', 
 'Adnan says he had nothing to do with Hae\'s murder. But can he prove it? And if he didn\'t do it, who did?', 
 '2014-10-10 12:00:00', 
 'https://example.com/episodes/serial-ep2.mp3', 
 3720, 
 2, 
 'serial-ep2', 
 NOW()),

((SELECT id FROM pages WHERE username = 'serial'), 
 'Episode 3: Leakin Park', 
 'A critical piece of evidence is called into question. What really happened in Leakin Park?', 
 '2014-10-17 12:00:00', 
 'https://example.com/episodes/serial-ep3.mp3', 
 3540, 
 3, 
 'serial-ep3', 
 NOW());

-- Sample Episodes for Radiolab
INSERT INTO episodes (page_id, title, description, pub_date, audio_url, duration, episode_number, guid, created_at) VALUES
((SELECT id FROM pages WHERE username = 'radiolab'), 
 'Colors', 
 'Why is the sky blue? Why is blood red? The world is full of colors, but how do we see them?', 
 '2024-01-15 10:00:00', 
 'https://example.com/episodes/radiolab-colors.mp3', 
 4200, 
 1, 
 'radiolab-colors', 
 NOW()),

((SELECT id FROM pages WHERE username = 'radiolab'), 
 'Animal Minds', 
 'What is it like to be a bat? Or a dog? Or an octopus? We explore the minds of animals.', 
 '2024-01-22 10:00:00', 
 'https://example.com/episodes/radiolab-animals.mp3', 
 3900, 
 2, 
 'radiolab-animals', 
 NOW());

-- Sample Analytics Data (for testing analytics dashboard)
INSERT INTO analytics (page_id, event_type, link_id, ip_address, user_agent, created_at) VALUES
-- Page views
((SELECT id FROM pages WHERE username = 'serial'), 'view', NULL, '192.168.1.1', 'Mozilla/5.0', DATE_SUB(NOW(), INTERVAL 2 DAY)),
((SELECT id FROM pages WHERE username = 'serial'), 'view', NULL, '192.168.1.2', 'Mozilla/5.0', DATE_SUB(NOW(), INTERVAL 1 DAY)),
((SELECT id FROM pages WHERE username = 'radiolab'), 'view', NULL, '192.168.1.3', 'Mozilla/5.0', DATE_SUB(NOW(), INTERVAL 3 DAY)),
((SELECT id FROM pages WHERE username = 'freakonomics'), 'view', NULL, '192.168.1.4', 'Mozilla/5.0', DATE_SUB(NOW(), INTERVAL 1 HOUR)),

-- Link clicks
((SELECT id FROM pages WHERE username = 'serial'), 'click', (SELECT id FROM links WHERE page_id = (SELECT id FROM pages WHERE username = 'serial') AND type = 'podcast_directory' LIMIT 1), '192.168.1.1', 'Mozilla/5.0', DATE_SUB(NOW(), INTERVAL 2 DAY)),
((SELECT id FROM pages WHERE username = 'freakonomics'), 'click', (SELECT id FROM links WHERE page_id = (SELECT id FROM pages WHERE username = 'freakonomics') AND type = 'affiliate' LIMIT 1), '192.168.1.5', 'Mozilla/5.0', DATE_SUB(NOW(), INTERVAL 5 HOUR));

-- Notes:
-- All test account passwords are: "TestPodcast123!" (except Cursor: "CursorAdmin123!")
-- These are bcrypt hashes (cost 12) for easy testing
-- The Cursor account should have admin access for testing admin panel functionality
-- RSS feed URLs are placeholder URLs - replace with actual feeds for testing RSS parsing
-- Episode audio URLs are placeholder - replace with actual URLs for testing playback


